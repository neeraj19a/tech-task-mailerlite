package testcases;

import base.BaseTest;
import io.qameta.allure.Feature;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.FieldsPage;
import pages.HomePage;
import pages.SubscribersPage;

@Feature("Subscribers")
public class SubscriberManagementTest extends BaseTest {

    private HomePage homePage;
    private SubscribersPage subscribersPage;
    private FieldsPage fieldsPage;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        homePage = new HomePage();
        subscribersPage = new SubscribersPage();
        fieldsPage = new FieldsPage();
    }

    @Test(priority = 1, description = "Create a New Subscriber")
    public void TC_0001() {
        Assert.assertEquals(homePage.returnHomePageText(), "Subscriber Management System", "Incorrect home page text");

        subscribersPage.createSubscriber("Test Subscriber", "test@gmail.com", "active");
        subscribersPage.validateSuccessMessage("Subscriber resource created successfully!");
        subscribersPage.validateSubscriberTableHeading();
        subscribersPage.validateSubscriberTable("Test Subscriber", "test@gmail.com", "active", "");
    }

    @Test(priority = 2, description = "Create a New Field and Add Subscriber")
    public void TC_0002() {
        fieldsPage.createField("Test", "string");

        fieldsPage.validateSuccessMessage("Field resource created successfully!");
        fieldsPage.validateFieldTableHeading();
        fieldsPage.validateFieldTable("Test", "string");

        subscribersPage.createSubscriber("Test Subscriber", "test@gmail.com", "active");

        subscribersPage.validateSuccessMessage("Subscriber resource created successfully!");
        subscribersPage.validateSubscriberTableHeading();
        subscribersPage.validateSubscriberTable("Test Subscriber", "test@gmail.com", "active", "Test: Test");
    }
    @AfterMethod(alwaysRun = true)
    public void cleanUp() {
        subscribersPage.deleteAllSubscribers();
        fieldsPage.deleteAllFields();
    }
}
