package apiTestCases;

import apiUtils.APIBase;
import io.qameta.allure.Allure;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class APIVerification extends APIBase {
    private static final Logger logger = LogManager.getLogger(APIVerification.class);

    public APIVerification(String url, String method) {
        super(url, method);
    }

    public static void responseCodeValidation(ResponseOptions<Response> response, int statusCode) {
        logToAllure("Response Details", response.getBody().asString());
        Assert.assertEquals(statusCode, response.getStatusCode());
        logger.info("Response code: " + response.getStatusCode());
        logToAllure("Response code: ", String.valueOf(response.getStatusCode()));
    }

    public static Long getResponseTime(ResponseOptions<Response> response) {
        long time = response.timeIn(TimeUnit.MILLISECONDS);
        logToAllure("Response Time: ", String.valueOf(time));
        return time;
    }

    // Method to log to Allure report
    public static void logToAllure(String stepName, String log) {
        Allure.step(stepName, () -> {
            Allure.attachment("Log", log);
        });
    }
}
