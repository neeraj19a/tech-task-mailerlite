package pages;

import io.qameta.allure.Step;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class AddSubsriberPage extends BasePage {
    private final Logger logger = LogManager.getLogger(AddSubsriberPage.class);
    @FindBy(id = "name")
    private WebElement nameInput;
    @FindBy(id = "email")
    private WebElement emailInput;
    @FindBy(xpath = "//label[@for='state'and contains(text(), 'State')]/following-sibling::div//select")
    private WebElement stateDropdown;
    @FindBy(xpath = "//label[@for='state'and contains(text(), 'Add Field')]/following-sibling::div//select")
    private WebElement addFieldDropdown;
    @FindBy(xpath = "//button[@type='submit' and contains(text(),'Create')]")
    private WebElement createButton;

    private final static String genericXpath = "//label[@for='%s'and contains(text(), '%s')]/following-sibling::div/div/input";

    @Step("Enter name of Subscriber")
    public AddSubsriberPage enterNameSubscriber(String subscriberName) {
        setText(nameInput, subscriberName);
        return this;
    }

    @Step("Enter email of Subscriber")
    public AddSubsriberPage enterEmailSubscriber(String email) {
        setText(emailInput, email);
        return this;
    }

    /**
     * Select a value from the dropdown by visible text.
     *
     * @param value The text of the option to select.
     */
    @Step("Select State for Subscriber")
    public AddSubsriberPage selectStateByVisibleText(String value) {
        Select select = new Select(stateDropdown);
        select.selectByVisibleText(value);
        return this;
    }

    /**
     * Select a value from the dropdown by visible text.
     */
    @Step("Select Add Field for Subscriber")
    public AddSubsriberPage selectFieldRandomly() {
        Select select = new Select(addFieldDropdown);
        List<WebElement> options = select.getOptions();
        logger.info("Available options size: " + options.size());

        // If only one option exists and it's "Please select one", select it
        if (options.size() == 1 && options.get(0).getText().equals("Please select one")) {
            logger.info("Only 'Please select one' is available. Selecting it.");
            select.selectByVisibleText(options.get(0).getText());
            return this;
        }

        // Otherwise, select a random valid option, avoiding "Please select one"
        List<WebElement> validOptions = options.stream()
                .filter(opt -> !opt.getText().equals("Please select one"))
                .collect(Collectors.toList());

        if (validOptions.isEmpty()) {
            logger.warn("No valid options available.");
            return this;
        }

        Random random = new Random();
        WebElement randomOption = validOptions.get(random.nextInt(validOptions.size()));

        logger.info("Randomly selected option: " + randomOption.getText());
        select.selectByVisibleText(randomOption.getText());
        addGenericField(randomOption.getText(), "Test");

        return this;
    }


    @Step("Click on Create Button")
    public HomePage clickCreateButton() {
        click(createButton);
        return new HomePage();
    }

    @Step("Add generic field")
    public AddSubsriberPage addGenericField(String fieldName, String textToAdd) {
        String xpath = String.format(genericXpath, fieldName, fieldName);
        WebElement field = driver.findElement(By.xpath(xpath));
        setText(field, textToAdd);
        return this;
    }

}
