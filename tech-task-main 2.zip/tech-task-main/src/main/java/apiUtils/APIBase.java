package apiUtils;


import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.io.output.WriterOutputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.PrintStream;
import java.io.StringWriter;

import static config.ConfigurationManager.configuration;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.MatcherAssert.assertThat;

public class APIBase {
    static StringWriter requestWriter;
    static PrintStream requestCapture;
    private RequestSpecBuilder builder = new RequestSpecBuilder();
    private String method;
    private String url;

    private final Logger logger = LogManager.getLogger(APIBase.class);

    public APIBase() {

    }

    // Private constructor to prevent direct instantiation
    public APIBase(String url, String method) {
        this.url = url;
        this.method = method;
    }


    // Static factory method
    public static APIBase createAPIWithoutToken(String uri, String method) {
        APIBase apiBase = new APIBase(configuration().BASE_URL() + uri, method);
        apiBase.configureAPIWithoutToken();
        return apiBase;
    }

    // Configure API
    private void configureAPIWithoutToken() {
        logger.info("URL-->" + this.url);
        builder.addHeader("Content-Type", "application/json");
        builder.addHeader("Origin", "http://localhost:5173");
        builder.addHeader("Referer", "http://localhost:5173");
    }

    /**
     * ExecuteAPI to execute the API for GET/POST/DELETE
     *
     * @return ResponseOptions<Response>
     */
    public ResponseOptions<Response> ExecuteAPI() {
        RequestSpecification requestSpecification = builder.build();

        RequestSpecification request = RestAssured.given().filter(new AllureRestAssured()).
                filter(new RestAssuredListener()).log().all();
        request.contentType(ContentType.JSON);
        request.spec(requestSpecification);

        ResponseOptions<Response> responseResponseOptions;

        requestWriter = new StringWriter();
        requestCapture = new PrintStream(new WriterOutputStream(requestWriter));

        if (this.method.equalsIgnoreCase(APIConstant.ApiMethods.POST)) {
            responseResponseOptions = request.filter(new RequestLoggingFilter(requestCapture)).post(this.url);
            requestCapture.flush();
            return responseResponseOptions;
        } else if (this.method.equalsIgnoreCase(APIConstant.ApiMethods.DELETE)) {
            responseResponseOptions = request.filter(new RequestLoggingFilter(requestCapture)).delete(this.url);
            requestCapture.flush();
            return responseResponseOptions;
        } else if (this.method.equalsIgnoreCase(APIConstant.ApiMethods.GET)) {
            responseResponseOptions = request.filter(new RequestLoggingFilter(requestCapture)).get(this.url);
            requestCapture.flush();
            return responseResponseOptions;
        } else if (this.method.equalsIgnoreCase(APIConstant.ApiMethods.PUT)) {
            responseResponseOptions = request.filter(new RequestLoggingFilter(requestCapture)).put(this.url);
            requestCapture.flush();
            return responseResponseOptions;
        }
        return null;
    }

    public static void jsonSchemaValidator(ResponseOptions<Response> response, String json) {
        assertThat(response.getBody().asString(), matchesJsonSchemaInClasspath(json));
    }
}
