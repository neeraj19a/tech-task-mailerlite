package config;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;

@LoadPolicy(LoadType.MERGE)
@Config.Sources({
        "system:properties",
        "classpath:general.properties",
        "classpath:configuration.properties"})
public interface Configuration extends Config {

    @Key("url")
    String url();

    @Key("BASE_URL")
    String BASE_URL();


}
