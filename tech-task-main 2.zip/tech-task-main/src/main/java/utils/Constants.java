package utils;

public class Constants {

    public static final int TIMEOUT = 3;

}

