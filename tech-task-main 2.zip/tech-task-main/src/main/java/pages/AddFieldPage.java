package pages;

import io.qameta.allure.Step;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class AddFieldPage extends BasePage {
    private final Logger logger = LogManager.getLogger(AddFieldPage.class);
    @FindBy(id = "title")
    private WebElement titleInput;

    @FindBy(xpath = "//label[@for='type'and contains(text(), 'Type')]/following-sibling::div//select")
    private WebElement typeDropdown;

    @FindBy(xpath = "//button[@type='submit' and contains(text(),'Create')]")
    private WebElement createButton;

    @Step("Enter title for Field")
    public AddFieldPage enterTitle(String title) {
        setText(titleInput, title);
        return this;
    }

    @Step("Enter Type for Field")
    public AddFieldPage selectType(String type) {
        Select select = new Select(typeDropdown);
        select.selectByVisibleText(type);
        return this;
    }

    @Step("Click on Create Button")
    public AddFieldPage clickCreateButton() {
        logger.info("Creating new field...");
        click(createButton);
        return this;
    }

}


