package pages;

import io.qameta.allure.Step;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class FieldsPage extends BasePage {

    private final Logger logger = LogManager.getLogger(FieldsPage.class);
    @FindBy(xpath = "(//a[@data-test-id='add-field-button' and contains(text(), ' Add field')])[1]")
    private WebElement addfieldButton;
    @FindBy(css = ".divide-x.divide-gray-200>th")
    private List<WebElement> fieldsTableHeading;
    @FindBy(xpath = "//tr[@data-test-id='fields-row']/td")
    private List<WebElement> fieldsTableElements;
    @FindBy(xpath = "(//a[@data-test-id='delete-field'])[1]")
    private WebElement deletefield;
    @FindBy(css = ".font-semibold.text-gray-800")
    private WebElement confirmationMessageText;
    @FindBy(css = ".text-sm.font-semibold.text-gray-500")
    private WebElement messageTextDetails;

    @Step("Click on Add field Button")
    public AddFieldPage clickAddfieldButton() {
        click(addfieldButton);
        return new AddFieldPage();
    }

    @Step("Return field Table Heading")
    public List<String> returnFieldTableHeading() {
        List<String> fieldTableHeading = new ArrayList<String>();
        for (WebElement element : fieldsTableHeading) {
            fieldTableHeading.add(element.getText());
        }
        return fieldTableHeading;
    }

    @Step("Return field Table Elements")
    public List<String> returnFieldTableElements() {
        List<String> fieldTableElements = new ArrayList<String>();
        for (WebElement element : fieldsTableElements) {
            fieldTableElements.add(element.getText());
        }

        return fieldTableElements;
    }

    @Step("Delete field")
    public FieldsPage deleteField() {
        refresh();
        HomePage homePage = new HomePage();
        FieldsPage fieldsPage = new FieldsPage();
        homePage.navigateToFieldsPage();
        if (isElementPresent(deletefield)) {
            click(deletefield);
            handleAlert("accept");
            String actualMessageTextFields = fieldsPage.returnConfirmationMessageText();
            Assert.assertEquals(actualMessageTextFields, "Success", "Looks like confirmation message is not correct");

            logger.info("Delete Field button clicked.");
        } else {
            logger.info("Delete Field button not found. Skipping step.");
        }
        return this;
    }

    @Step("Delete All fields")
    public FieldsPage deleteAllFields() {
        refresh();
        HomePage homePage = new HomePage();
        FieldsPage fieldsPage = new FieldsPage();
        homePage.navigateToFieldsPage();

        if (!isElementPresent(deletefield)) {
            logger.info("No fields found to delete. Skipping step.");
            return this;
        }
        while (isElementPresent(deletefield)) {
            click(deletefield);
            handleAlert("accept");
            String actualMessageTextFields = fieldsPage.returnConfirmationMessageText();
            Assert.assertEquals(actualMessageTextFields, "Success", "Looks like confirmation message is not correct");
            closeMessage();
            logger.info("Delete Field button clicked.");
        }
        return this;
    }

    @Step("Return Confirmation Message Text")
    public String returnConfirmationMessageText() {
        waitForElementToBeVisible(confirmationMessageText);
        return confirmationMessageText.getText();
    }

    @Step("Return Message Text Details")
    public String returnMessageTextDetails() {
        return messageTextDetails.getText();
    }

    public FieldsPage createField(String title, String type) {
        new HomePage().navigateToFieldsPage()
                .clickAddfieldButton()
                .enterTitle(title)
                .selectType(type)
                .clickCreateButton();
        return this;
    }

    public void validateFieldTableHeading() {
        List<String> expectedTableHeading = List.of("#", "Title", "Type", "Actions");
        List<String> actualTableHeading = returnFieldTableHeading();
        Assert.assertEquals(actualTableHeading, expectedTableHeading, "Field Table heading is incorrect");
    }

    public void validateFieldTable(String title, String type) {
        List<String> expectedTableDetails = List.of("1", title, type, "");
        List<String> actualTableDetails = returnFieldTableElements();
        Assert.assertEquals(actualTableDetails, expectedTableDetails, "Field Table details are incorrect");
    }

}
