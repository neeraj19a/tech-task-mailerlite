package apiTestCases;

import apiHelper.APITestCasesHelper;
import apiUtils.APIBase;
import apiUtils.APIConstant;
import base.BaseTest;
import io.qameta.allure.Step;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SubscribersPage;

import static apiTestCases.APIVerification.logToAllure;

public class APITest extends BaseTest {
    private static final Logger logger = LogManager.getLogger(APITest.class);
    private static final String SUBSCRIBER_NAME = "Test Subscriber";
    private static final String SUBSCRIBER_EMAIL = "test@gmail.com";
    private static final String SUBSCRIBER_STATE = "active";

    private ResponseOptions<Response> response;
    private String subscriberId;
    private HomePage homePage;
    private SubscribersPage subscribersPage;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        homePage = new HomePage();
        subscribersPage = new SubscribersPage();
    }

    @Test
    public void TC_0003() {
        // To make test case atomic and independent creating test data for Subscriber first
        createSubscriberViaUI();
        // Validating the subscriber details via API
        validateSubscriberViaAPI();
    }

    @Step("Create a new subscriber via UI")
    private void createSubscriberViaUI() {
        Assert.assertEquals(homePage.returnHomePageText(), "Subscriber Management System",
                "The home page text does not match the expected value.");

        subscribersPage.createSubscriber(SUBSCRIBER_NAME, SUBSCRIBER_EMAIL, SUBSCRIBER_STATE);
        subscribersPage.validateSuccessMessage("Subscriber resource created successfully!");
        subscribersPage.validateSubscriberTableHeading();
        subscribersPage.validateSubscriberTable(SUBSCRIBER_NAME, SUBSCRIBER_EMAIL, SUBSCRIBER_STATE, "");
    }

    @Step("Validate the subscriber via API")
    private void validateSubscriberViaAPI() {
        APIBase privateAPI = APIBase.createAPIWithoutToken(APIConstant.APIPaths.subscribers, "GET");
        response = privateAPI.ExecuteAPI();

        APIVerification.responseCodeValidation(response, 200);
        APIVerification.getResponseTime(response);

        logger.info("API Response: {}", response.getBody().asString());
        subscriberId = new APITestCasesHelper().getSubscriberId(response);
        logToAllure("subscriberId", subscriberId);

        boolean isValid = APITestCasesHelper.validateSubscriberResponse(response);
        Assert.assertTrue(isValid, "The subscriber response is invalid.");

        new APIBase().jsonSchemaValidator(response, "api-schema/GetSubscribers.json");
    }

    @AfterMethod(alwaysRun = true)
    public void cleanUp() {
        subscribersPage.deleteAllSubscribers();
    }
}