package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {
    @FindBy(xpath = "//a[@data-test-id='home-tab' and contains(text(), 'Home')][0]")
    private WebElement homeTab;
    @FindBy(xpath = "(//a[@data-test-id='subscribers-tab' and contains(text(), ' Subscribers ')])[1]")
    private WebElement subscribersTab;
    @FindBy(xpath = "(//a[@data-test-id='fields-tab' and contains(text(), ' Fields')])[1]")
    private WebElement fieldsTab;
    @FindBy(css = ".font-bold.tracking-tight")
    private WebElement subsciberManagementSystemText;


    @Step("Navigate to Subscribers Tab")
    public SubscribersPage navigateToSubscribersPage() {
        click(subscribersTab);
        return new SubscribersPage();
    }

    @Step("Navigate to Fields Tab")
    public FieldsPage navigateToFieldsPage() {
        click(fieldsTab);
        return new FieldsPage();
    }

    @Step("Return Home Page text")
    public String returnHomePageText() {
        return subsciberManagementSystemText.getText();
    }

}
