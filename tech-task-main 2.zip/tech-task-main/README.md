# Technologies and Libraries Used

## Languages and Frameworks

This project utilizes the following technologies:

- **[Java 11](https://docs.oracle.com/en/java/javase/11/install/installation-jdk-macos.html#GUID-2FE451B0-9572-4E38-A1A5-568B77B146DE)** - Primary programming language
- **[TestNG](https://testng.org/doc/)** - Unit testing framework
- **[Selenium WebDriver](https://www.selenium.dev/)** - Web automation framework (Java binding)
- **[Allure Report](https://docs.qameta.io/allure/)** - Test reporting framework
- **[Log4J2](https://logging.apache.org/log4j/2.x/)** - Logging management
- **[WebDriverManager](https://github.com/bonigarcia/webdrivermanager)** - Selenium driver management
- **[Owner](http://owner.aeonbits.org/)** - Property file management

---

## Prerequisites

Ensure the following tools are installed:

- **Java 11**
- **Maven**
- **Allure**

### Allure Installation

#### Windows
```sh
scoop install allure
```

#### macOS
```sh
brew install allure
```

#### Linux
```sh
sudo apt-add-repository ppa:qameta/allure
sudo apt-get update
sudo apt-get install allure
```

#### Verify Installation
```sh
allure --version
```

---

## Framework Overview

This framework follows the **Page Object Model (POM)** pattern with **Page Factory** and **WebDriverFactory**.

### Features:
- **Supported Browsers:** Chrome
- **Supported OS:** Windows, Unix, macOS

### Key Components:
- **Base Page:** Contains reusable page automation methods.
- **ListenerClass:** Implements `ITestListener` to capture test execution logs.
- **Retry & RetryListenerClass:** Implements `IRetryAnalyzer` and `IAnnotationTransformer` for test retries.
- **WebDriverManager:** Dynamically manages WebDriver binaries.
- **BaseTest:** Manages browser sessions and test execution.
- **WebEventListener:** Captures WebDriver events.

---

## Running UI Test Cases

### Steps:
1. Navigate to `src/test/TestNG-UI.xml`
2. Run tests from the terminal:
   ```sh
   mvn clean test -Dsurefire.suiteXmlFiles=src/test/TestNG-UI.xml
   ```

### Expected Output:
```sh
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

### Generating Allure Reports
```sh
allure generate allure-results --clean -o allure-report
```
Open `allure-report/index.html` in a browser.

#### UI Test Execution Result:
![UI Test Execution](img_1.png)

#### UI Allure Report:
![UI Allure Report](img_2.png)

---

## Running API Test Cases

### Steps:
1. Navigate to `src/test/TestNG-API.xml`
2. Run tests from the terminal:
   ```sh
   mvn clean test -Dsurefire.suiteXmlFiles=src/test/TestNG-API.xml
   ```

### Expected Output:
```sh
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

### Generating Allure Reports
```sh
allure generate allure-results --clean -o allure-report
```
Open `allure-report/index.html` in a browser.

#### API Test Execution Result:
![API Test Execution](img_3.png)

#### API Allure Report:
![API Allure Report](img_4.png)

---