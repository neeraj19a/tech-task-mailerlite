package apiHelper;

import api.SubscriberDataResponseBody;
import api.SubscriberResponseBody;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class APITestCasesHelper {
    private static final Logger logger = LoggerFactory.getLogger(APITestCasesHelper.class);

    public static String getSubscriberId(ResponseOptions<Response> response) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            // Convert response to SubscriberResponse POJO
            SubscriberDataResponseBody subscriberResponse = mapper.readValue(response.getBody().asString(), SubscriberDataResponseBody.class);

            // Extract 'id' from the first subscriber in the list
            if (subscriberResponse.getData() != null && !subscriberResponse.getData().isEmpty()) {
                return String.valueOf(subscriberResponse.getData().get(0).getId());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static boolean validateSubscriberResponse(ResponseOptions<Response> response) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SubscriberDataResponseBody subscriberResponse = objectMapper.readValue(response.getBody().asString(), SubscriberDataResponseBody.class);

            if (subscriberResponse == null || subscriberResponse.getData() == null) {
                return false;
            }

            for (SubscriberResponseBody subscriber : subscriberResponse.getData()) {
                if (!isValidSubscriber(subscriber)) {
                    return false; // If any subscriber is invalid, return false
                }
            }
            return true; // All subscribers are valid
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean isValidSubscriber(SubscriberResponseBody subscriber) {
        return subscriber.getId() != null && subscriber.getEmail() != null && !subscriber.getEmail().isEmpty() && subscriber.getName() != null && !subscriber.getName().isEmpty() && subscriber.getState() != null && !subscriber.getState().isEmpty();
    }

}