package pages;

import driver.DriverManager;
import io.qameta.allure.Step;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utils.Constants;
import utils.Log;

import java.time.Duration;

import static org.openqa.selenium.support.PageFactory.initElements;

public class BasePage {
    private final Logger logger = LogManager.getLogger(BasePage.class);
    public WebDriver driver = DriverManager.getDriver();
    JavascriptExecutor executor = (JavascriptExecutor) DriverManager.getDriver();

    public WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.TIMEOUT));

    @FindBy(css = ".font-semibold.text-gray-800")
    private WebElement confirmationMessageText;
    @FindBy(css = ".text-sm.font-semibold.text-gray-500")
    private WebElement messageTextDetails;
    @FindBy(css = ".inline-flex.text-gray-400.bg-white.rounded-md>svg")
    private WebElement closeMessage;

    //configuration static object to read from Property File
    protected BasePage() {
        initElements(new AjaxElementLocatorFactory(DriverManager.getDriver(), Constants.TIMEOUT), this);
    }

    public void click(WebElement element) {
        try {
            waitelementToBeClickable(element);
            element.click();
        } catch (Exception e) {
            Log.info("Exception found on clicking Element-->" + element + "-->" + e);
            executor.executeScript("arguments[0].click();", element);
        }
    }

    /**
     * Explicit Wait Utility function to wait for particular element to be clickable
     *
     * @param element
     */
    public void waitelementToBeClickable(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(45));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Function to get URL of the current page
     *
     * @return
     */
    public String getUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Explicit Wait Utility function to wait for particular element to be visible
     *
     * @param element
     */
    public void waitForElementToBeVisible(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.TIMEOUT));
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void setText(WebElement element, String text) {
        try {
            waitelementToBeClickable(element);
            element.click();
            element.sendKeys(text);
        } catch (Exception e) {
            Log.info("Exception found-->" + e);
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].value='" + text + "';", element);
        }
    }

    public String getText(WebElement element) {
        waitForElementToBeVisible(element);
        return element.getText();
    }

    public void refresh() {
        driver.navigate().refresh();
    }

    public void handleAlert(String action) {
        try {
            Alert alert = driver.switchTo().alert(); // Switch to the alert

            if ("accept".equalsIgnoreCase(action)) {
                alert.accept();  // Clicks OK
            } else if ("dismiss".equalsIgnoreCase(action)) {
                alert.dismiss(); // Clicks Cancel
            }

            logger.info("Alert handled successfully.");
        } catch (Exception e) {
            logger.info("No alert present: " + e.getMessage());
        }
    }

    // Utility method to check if a WebElement is present and displayed
    public boolean isElementPresent(WebElement element) {
        try {
            return element != null && element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void validateSuccessMessage(String expectedDetails) {
        waitForElementToBeVisible(confirmationMessageText);
        Assert.assertEquals(returnConfirmationMessageText(), "Success", "Confirmation message incorrect");
        Assert.assertEquals(returnMessageTextDetails(), expectedDetails, "Message details incorrect");
        closeMessage();
    }

    @Step("Return Confirmation Message Text")
    public String returnConfirmationMessageText() {
        waitForElementToBeVisible(confirmationMessageText);
        return confirmationMessageText.getText();
    }

    @Step("Return Message Text Details")
    public String returnMessageTextDetails() {
        return messageTextDetails.getText();
    }

    @Step("Close Message")
    public void closeMessage() {
        logger.info("Closing message now");
        click(closeMessage);
    }
}