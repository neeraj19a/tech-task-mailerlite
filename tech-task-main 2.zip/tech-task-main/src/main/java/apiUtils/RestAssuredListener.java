package apiUtils;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RestAssuredListener implements Filter {
    private static final Logger logger = LogManager.getLogger(RestAssuredListener.class);

    @Override
    public Response filter(FilterableRequestSpecification requestSpec, FilterableResponseSpecification responseSpec,
                           FilterContext ctx) {
        Response response = ctx.next(requestSpec, responseSpec);
        logger.info(
                "------------------------------------------------------------------------------------" +
                        "\n         URI    : " + requestSpec.getURI() +
                        "\n         Method : " + requestSpec.getMethod() +
                        "\n------------------------------------------------------------------------------------" +
                        "\nRequest :   \n" + requestSpec.getBody() +
                        "\n Response :  \n" + response.getBody().prettyPrint());
        return response;
    }
}