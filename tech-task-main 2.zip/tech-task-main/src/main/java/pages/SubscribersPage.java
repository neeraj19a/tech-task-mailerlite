package pages;

import io.qameta.allure.Step;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class SubscribersPage extends BasePage {
    private final Logger logger = LogManager.getLogger(SubscribersPage.class);
    @FindBy(xpath = "(//a[@data-test-id='add-subscriber-button' and contains(text(), ' Add subscriber')])[1]")
    private WebElement addSubscriberButton;
    @FindBy(css = ".divide-x.divide-gray-200>th")
    private List<WebElement> subscribersTableHeading;
    @FindBy(xpath = "//tr[@data-test-id='subscriber-row']/td")
    private List<WebElement> subscribersTableElements;
    @FindBy(xpath = "(//a[@data-test-id='delete-subscriber'])[1]")
    private WebElement deleteSubscriber;

    @Step("Click on Add Subscriber Button")
    public AddSubsriberPage clickAddSubscriberButton() {
        click(addSubscriberButton);
        return new AddSubsriberPage();
    }

    @Step("Return Subscriber Table Heading")
    public List<String> returnSubscriberTableHeading() {
        List<String> subscriberTableHeading = new ArrayList<String>();
        for (WebElement element : subscribersTableHeading) {
            subscriberTableHeading.add(element.getText());
        }
        return subscriberTableHeading;
    }

    @Step("Return Subscriber Table Elements")
    public List<String> returnSubscriberTableElements() {
        refresh();
        waitForElementToBeVisible(subscribersTableElements.get(3));
        List<String> subscriberTableElements = new ArrayList<String>();
        for (WebElement element : subscribersTableElements) {
            subscriberTableElements.add(element.getText());
        }

        return subscriberTableElements;
    }

    @Step("Delete Subscriber")
    public SubscribersPage deleteSubscriber() {
        refresh();
        HomePage homePage = new HomePage();
        SubscribersPage subscibersPage = new SubscribersPage();
        homePage.navigateToSubscribersPage();
        if (isElementPresent(deleteSubscriber)) {
            click(deleteSubscriber);
            handleAlert("accept");
            String actualMessageText = subscibersPage.returnConfirmationMessageText();
            Assert.assertEquals(actualMessageText, "Success", "Looks like confirmation message is not correct");

            String actualMessageTextDetails = subscibersPage.returnMessageTextDetails();
            Assert.assertEquals(actualMessageTextDetails, "Subscriber resource deleted successfully!", "Looks like actualMessageTextDetails is not correct");

            logger.info("Subscriber Deleted.");
        } else {
            logger.info("Delete Subscriber button not found. Skipping step.");
        }
        return this;
    }

    public SubscribersPage createSubscriber(String name, String email, String state) {
        new HomePage().navigateToSubscribersPage()
                .clickAddSubscriberButton()
                .enterNameSubscriber(name)
                .enterEmailSubscriber(email)
                .selectStateByVisibleText(state)
                .selectFieldRandomly()
                .clickCreateButton();
        return this;
    }

    public void validateSubscriberTableHeading() {
        List<String> expectedTableHeading = List.of("#", "Name", "Email", "State", "Addtional Info", "Actions");
        List<String> actualTableHeading = returnSubscriberTableHeading();
        Assert.assertEquals(actualTableHeading, expectedTableHeading, "Subscriber Table heading is incorrect");
    }

    public void validateSubscriberTable(String name, String email, String state, String additionalInfo) {
        List<String> expectedTableDetails = List.of("1", name, email, state, additionalInfo, "");
        List<String> actualTableDetails = returnSubscriberTableElements();
        Assert.assertEquals(actualTableDetails, expectedTableDetails, "Subscriber Table details are incorrect");
    }

    @Step("Delete All Subscribers")
    public SubscribersPage deleteAllSubscribers() {
        refresh();
        HomePage homePage = new HomePage();
        SubscribersPage subscibersPage = new SubscribersPage();
        homePage.navigateToSubscribersPage();

        // Check if the element is present before entering the loop
        if (!isElementPresent(deleteSubscriber)) {
            logger.info("No subscribers found to delete.");
            return this;
        }

        while (isElementPresent(deleteSubscriber)) {
            click(deleteSubscriber);
            handleAlert("accept");

            String actualMessageText = subscibersPage.returnConfirmationMessageText();
            Assert.assertEquals(actualMessageText, "Success", "Looks like confirmation message is not correct");

            String actualMessageTextDetails = subscibersPage.returnMessageTextDetails();
            Assert.assertEquals(actualMessageTextDetails, "Subscriber resource deleted successfully!", "Looks like actualMessageTextDetails is not correct");
            closeMessage();
            logger.info("Subscriber Deleted.");
        }

        return this;
    }

}
